function toggleMenu(){
    var menuToggle = document.querySelector('.menuToggle');
    var navigation = document.querySelector('.navigation');
    menuToggle.classList.toggle('active');
    navigation.classList.toggle('active');
}